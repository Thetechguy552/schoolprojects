package Driver;

import View.BasicFrameExample;
import View.BorderLayoutExample;
import View.FlowLayoutExample;
import View.GridLayoutExample;
import View.JPanelExample;

public class Driver {
    
    public static void main(String[] args) {
        
        int option = 4;
        
        // Creates an instance of the basic frame class, which in turn will 
        // construct a JFrame.
        switch(option)
        {
            case 0: 
                new BasicFrameExample();
                break;
            case 1: 
                new FlowLayoutExample();
                break;
            case 2: 
                new GridLayoutExample();
                break;
            case 3: 
                new BorderLayoutExample();
                break;
            case 4: 
                new JPanelExample();
                break;
        }
    }   
}
package View;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.JFrame;

public class BasicFrameExample {
    
    public BasicFrameExample() {
        createFrame();
    }
    
    /**
     * This method simply is called from the constructor to create a new JFrame 
     * object with all it's settings.
     */
    public void createFrame() {
        
        // Create a new JFrame object.
        JFrame frame = new JFrame("Practice");
        
        /**
        * Add a new JComponent to the frame, the component added is a JButton.
        * Please note: A frame may only have one component added to it as a
        * container object resides in a component where only one component 
        * may be allowed per container. 
        * In the later examples we will see how to add more components to a frame.
        */
        JButton jbtClickMe = new JButton("Click Me!");
        frame.add(jbtClickMe);
        
        // In the event we wanted to remove a component. 
        //frame.remove(jbtClickMe);
        
        /**
        * Sets the size of the frame in pixels, 500px in length, 300px in width. 
        * It is best practice to set the frame's size before settings it's location. 
        * The reason is because if we set the size after the location the frame won't 
        * truly be centered. Try it to see the effect. 
        */
        frame.setSize(500, 300);
        
        // Center the frame.
        frame.setLocationRelativeTo(null);
        
        // Or choose a custom location.
        //frame.setLocationRelativeTo(setCustomFramePosition(frame));
        
        // Set the default close operation. This ensures the program terminates on exit.
        // Otherwise the program would still be running even though the frame is gone.
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Lastly, we must set the frame to become visible.
        frame.setVisible(true);
    }
    
    /**
     * Utilizes the dimension and point help objects to set a custom location 
     * for a frame. Right now the method demonstrates the manual way to center
     * a JFrame. The Point object returned from this method is used to pass
     * to the setLocationRelativeTo() method to set a custom position.
     * @param frame
     * @return
     */
    public Point setCustomFramePosition(JFrame frame)
    {
        // Use the TookKit static object method to get the screensize of the monitor.
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        
        // Determine the center point of the screen. 
        Point middle = new Point(screenSize.width / 2, screenSize.height / 2);
        
        // Create a custom location for the frame.
        Point newLocation = new Point(middle.x - (frame.getWidth() / 2), middle.y - (frame.getHeight() / 2));
        return newLocation;
    }
}
package View;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class BorderLayoutExample extends JFrame {
    
    /**
     * Before reviewing this class please look at the flow-layout.
     * Notice in this example how we extend JFrame rather than creating a specific 
     * object for the frame. This shows an alternative way to creates frame.
     * The choice to select between the two options depends on the use-case.
     */
    public BorderLayoutExample() {
        createFrame();
    }
    
    /**
     * This examples demonstrates the use of a border layout which orders 
     * components based on a compass system being Center, North, West, South, and East.
     * Thus the frame is broken up into five components. We must manually specify
     * where the components will go as an additional parameter to the add() method 
     * of JFrame. This extra parameter is exclusive to the border layout.
     */
    public void createFrame() {
        
        /**
        * The first parameter represents the horizontal gap between components in px. 
        * The second parameter represents the vertical gap between components in px.
        */
        setLayout(new BorderLayout(5, 5));
        
        /**
        * Add a series of JComponents to the frame to demonstrate border layout.
        * Please note we can only have a maximum of five components as this is 
        * a constraint of border layout. It is unnecessary to have exactly five
        * components we can have 1 and Java will resize the components based
        * on the number available. Try commenting out one add() line at a time 
        * to see the effect.
        */
        add(new JButton("Center!"), BorderLayout.CENTER);
        add(new JButton("North!"), BorderLayout.NORTH);
        add(new JButton("West!"), BorderLayout.WEST);
        add(new JButton("South!"), BorderLayout.SOUTH);
        add(new JButton("East!"), BorderLayout.EAST);
        
        // Set the properties of the frame.
        setTitle("Border layout example!");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }   
}
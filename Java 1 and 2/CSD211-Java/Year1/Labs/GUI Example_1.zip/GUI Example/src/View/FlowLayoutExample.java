package View;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class FlowLayoutExample extends JFrame{
    
    /**
     * Notice in this example how we extend JFrame rather than creating a specific 
     * object for the frame. This shows an alternative way to creates frame.
     * The choice to select between the two options depends on the use-case.
     */
    public FlowLayoutExample() {
        createFrame();
    }
    
    /**
     * Each container contains a layout manager, which is an object responsible 
     * for laying out the GUI components in the container. In the BasicFrameExample
     * we did not specify where to place the button, Java knew where to place it
     * based on the layout manager behind the scenes. This examples demonstrates 
     * the use of a flow layout which orders components from left to right in the 
     * order which they are added. When one row on the frame is filled another
     * row is started. You can also adjust the way the components are aligned.
     * You can either choose right, left, or center.
     */
    public void createFrame() {
        
        /**
        * The first parameter of flow-layout is the position. The default is FlowLayout.LEFT
        * The second parameter represents the horizonal gap between components in px.
        * The third parameter represents the vertical gap between components in px. 
        * Try changing CENTER to LEFT or RIGHT to see effect and maximize the window.
        */
        setLayout(new FlowLayout(FlowLayout.CENTER, 50, 50));
        
        /**
        * Add a series of JComponents to the frame to demonstrate flow layout.
        * Please note if we create an instance of a JComponent such as JButton 
        * and we add the same reference to the component it will only be added once.
        * We must create a separate object for each different component.
        */
        add(new JButton("Click Me 1!"));
        add(new JButton("Click Me 2!"));
        add(new JButton("Click Me 3!"));
        add(new JButton("Click Me 4!"));
        add(new JButton("Click Me 5!"));
        add(new JButton("Click Me 6!"));
        add(new JLabel("Label 1"));
        add(new JTextField("Preset text", 25));
        
        // Set the properties of the frame.
        setTitle("Flow layout example!");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
package View;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class GridLayoutExample extends JFrame{
    
    /**
     * Notice in this example how we extend JFrame rather than creating a specific 
     * object for the frame. This shows an alternative way to creates frame.
     * The choice to select between the two options depends on the use-case.
     */
    public GridLayoutExample() {
        createFrame();
    }
    
    /**
     * This examples demonstrates the use of a grid layout which orders 
     * components in a matrix form through specified rows and columns. 
     * If we add more JComponents then there are rows and columns the 
     * grid layout will automatically compensate by expanding. Similar to 
     * flow layout the components are ordered from left to right, starting at
     * the first row and column (0,0) moving across each column then on to the 
     * next row. As the grid layout will automatically expand please note that 
     * the expansion is based on the dimensions. Research for this additional details.
     * For now it is best to place the exact number of components in the grid layout.
     * Resizing the frame will leave the components unchanged.
     */
    public void createFrame() {
        
        /**
        * The first parameter represents the number of rows for the grid.
        * The second parameter represents the number of columns for the grid.
        * The third parameter represents the horizontal gap between components in px. 
        * The fourth parameter represents the vertical gap between components in px.
        */
        setLayout(new GridLayout(3, 3, 5, 5));
        
        /**
        * Add a series of JComponents to the frame to demonstrate flow layout.
        * Please note if we create an instance of a JComponent such as JButton 
        * and we add the same reference to the component it will only be added once.
        * We must create a separate object for each different component.
        */
        add(new JButton("Click Me 1!"));
        add(new JButton("Click Me 2!"));
        add(new JButton("Click Me 3!"));
        add(new JButton("Click Me 4!"));
        add(new JButton("Click Me 5!"));
        add(new JButton("Click Me 6!"));
        add(new JButton("Click Me 7!"));
        add(new JButton("Click Me 8!"));
        add(new JButton("Click Me 9!"));
        
        // Set the properties of the frame.
        setTitle("Grid layout example!");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
}
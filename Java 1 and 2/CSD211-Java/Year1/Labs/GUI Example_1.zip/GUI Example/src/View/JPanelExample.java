package View;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class JPanelExample extends JFrame {
    
    public JPanelExample() {
        createFrame();
    }
    
    /**
     * This examples demonstrates the use of a JPanel to act as a sub-container 
     * to add additional layouts/components to a frame. The following code initially
     * sets a border layout for the frame then creates two additional JPanels to act
     * as completely separate containers with different layouts. Once all the components
     * are created the two panels are added to the overall frame's layout.
     */
    public void createFrame() {
     
        // First set the initial layout.
        setLayout(new BorderLayout());
        
        // Create a separate JPanel to hold a set of JComponents.
        JPanel p1 = new JPanel();
        
        // Set the layout of the JPanel.
        p1.setLayout(new GridLayout(4, 3));
        
        // Populate the panel with 9 buttons representing the numbers 1 - 9.
        for (int i = 1; i <= 9; i++) {
            p1.add(new JButton("" + i));
        }
        
        // Add three additional buttons to the layout. 
        p1.add(new JButton("" + 0));
        p1.add(new JButton("Start"));
        p1.add(new JButton("Stop"));
        
        // Create another separate JPanel for a new layout. 
        // In this panel we demonstrate the use of setting the layout through 
        // the constructor rather than using the setter method. 
        JPanel p2 = new JPanel(new BorderLayout());
        
        // Add a text field to the second panel setting the text of the text field 
        // to the current date.
        p2.add(new JTextField(new Date().toString()), BorderLayout.NORTH);
        
        // Add the first panel to the second panel 
        p2.add(p1, BorderLayout.CENTER);
        
        // Create a new custom JButton setting colors, font, and a tooltip. 
        JButton foodPlacement = new JButton("Food to be placed here");
        foodPlacement.setBackground(new Color(255, 205, 255));
        foodPlacement.setForeground(new Color(100, 205, 255));
        foodPlacement.setFont(new Font("SansSerif", Font.BOLD + Font.ITALIC, 16));
        foodPlacement.setToolTipText("Place some food here to warm up!");
        
        // Alternative way to add colors.
        //foodPlacement.setBackground(Color.RED);
        
        // Add the custom JButton to the frame at the west position. 
        add(foodPlacement, BorderLayout.WEST);
        
        // Add the second panel to the center position of the frame.
        add(p2, BorderLayout.CENTER);
        
        // Set the properties of the frame.
        setTitle("Microwave Example!");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }      
}
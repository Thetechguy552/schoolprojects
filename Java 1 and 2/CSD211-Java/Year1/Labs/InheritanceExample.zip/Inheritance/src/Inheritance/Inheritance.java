package Inheritance;

import Models.Student;

/**
 * Main class to execute the inheritance program. 
 * Note: Every class in Java inherits the base object class
 * which is the absolute base of any defined object. 
 * Imagine after every class behind the scenes "extends Object"
 * comes right after the class name. The exception is when a class
 * extends another class, it can be said that class's inheritance is modified 
 * from the base Object class to the extending class. 
 */
public class Inheritance {

    public static void main(String[] args) {
        
        Student student1 = new Student(1, true, "Computer Science", 60, "Joe", "Don", 32);
        System.out.println(student1.toString());

        Student student2 = new Student(2, true, "Biology", 70, "John", "Doe", "Male", 25);
        System.out.println(student2.toString());  
        
        System.out.println(Student.getNumOfStudents());
    }  
}
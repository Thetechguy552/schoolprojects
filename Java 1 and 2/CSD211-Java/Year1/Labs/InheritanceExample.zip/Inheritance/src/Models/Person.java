package Models;

/**
 * Superclass to be extended from classes which require the data properties of 
 * a base person. This class contains protected constructors and methods as
 * we only want subclasses to access these properties. The data members are 
 * private so they can retain class access. If we do not explicity provide
 * a default constructor for the base class the constructor in the subclass
 * will throw an error if a matching constructor with the super keyword is not 
 * defined.
 */
public class Person {
    
    private String firstName; 
    private String lastName; 
    private String gender;
    private int age;
    
    protected Person(String firstName, String lastName, String gender, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.age = age;
    }
    
    protected String getFullName(){
        return firstName + " " + lastName;
    }
    
    protected String getFirstName() {
        return firstName;
    }

    protected void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    protected String getLastName() {
        return lastName;
    }

    protected void setLastName(String lastName) {
        this.lastName = lastName;
    }

    protected String getGender() {
        return gender;
    }

    protected void setGender(String gender) {
        this.gender = gender;
    }

    protected int getAge() {
        return age;
    }

    protected void setAge(int age) {
        this.age = age;
    }

    /**
     * The @Override annotation lets the compiler know this method must be properly 
     * overriden from the super class. This help prevent errors.
     * In this base class we are actually overriding the base class Object 
     * toString method which by default prints out the class name followed by the memory address.
     */
    @Override
    public String toString() {
        return "Person{" + "firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", age=" + age + '}';
    }   
}
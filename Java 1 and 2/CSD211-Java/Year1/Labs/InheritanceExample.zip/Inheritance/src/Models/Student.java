package Models;

/**
 * Subclass which extends the Person class thus inheriting it's properties and 
 * methods. The extends keyword tell the compiler that the Student class extends
 * the Person class thus acquiring all it's methods and properties.
 */
public class Student extends Person {
    
    private static final String DEFAULT_GENDER = "Unspecified";
    private static int numOfStudents;
    private int studentId; 
    private boolean tutitionPaid;
    private String major;
    private int overallAverage;
    
    public Student(int studentId, boolean tutitionPaid, String major, int overallAverage, String firstName, String lastName, int age) {
        
        // Invoke the constructor with additional arguments to continue object creation.
        this(studentId, tutitionPaid, major, overallAverage, firstName, lastName, DEFAULT_GENDER, age);
    }
    
    public Student(int studentId, boolean tutitionPaid, String major, int overallAverage, String firstName, String lastName, String gender, int age) {
        
        /**
        * The keyword super refers the superclass and can be used to invoke the 
        * super class's methods and constructors. It must appear as the first line
        * in the subclass constructor. If we attempt to use the super class name
        * to invoke the constructor this will cause a syntax error.
        */
        super(firstName, lastName, gender, age);
        this.studentId = studentId;
        this.tutitionPaid = tutitionPaid;
        this.major = major;
        this.overallAverage = overallAverage;
        this.numOfStudents++;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public boolean isTutitionPaid() {
        return tutitionPaid;
    }

    public void setTutitionPaid(boolean tutitionPaid) {
        this.tutitionPaid = tutitionPaid;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public int getOverallAverage() {
        return overallAverage;
    }

    public void setOverallAverage(int overallAverage) {
        this.overallAverage = overallAverage;
    }
    
    public static int getNumOfStudents() {
        return numOfStudents;
    }
    
    /**
     * Notice in this method we call the super.toString() method 
     * as we want to see the details of the base class in addition 
     * to the details of this subclass. 
     * 
     * The @Override annotation lets the compiler know this method must be properly 
     * overriden from the super class. This help prevent errors.
     * For example change the name of toString to ToString and an error
     * will come up indicating the method has not been properly overridden.
     * In order to properly override a method it must exist in the superclass
     * and have the same signature and name.
     */
    @Override
    public String toString() {
        return super.toString() + " Student{" + "studentId=" + studentId + ", tutitionPaid=" + tutitionPaid + ", major=" + major + ", overallAverage=" + overallAverage + '}';
    }
}
package qusetion3;
/**
 * Author Jonathan Kelly
 */

public class Qusetion3 {
    
    public static void main(String[] args) {

    }
}
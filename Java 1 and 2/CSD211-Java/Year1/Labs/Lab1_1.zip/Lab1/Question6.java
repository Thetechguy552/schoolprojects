package question6;
/**
 * Author Jonathan Kelly
 */
public class Question6 {

    public static void main(String[] args) {

        
    }  
}

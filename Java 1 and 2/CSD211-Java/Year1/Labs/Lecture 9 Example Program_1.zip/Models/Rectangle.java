/* 
* If a class is in a package the start of file must have the first line of code 
* denoting the package in which the class belongs to. Remember the reason why
* a comment can be put here is because comments are ignored by the compiler.
*/ 
package Models;

/**
 * The following is a class representation of a simple rectangle. 
 * It's data members are length, width, and an integer representing the
 * number of rectangles created. 
 * 
 * It is important to remember in every file there must be at least one 
 * public class which matches the name of the file it resides in. It
 * is possible to place another class in the same file but it cannot be 
 * public nor seen outside of the file. Please go to the bottom of this file
 * for an example of putting another class in the same file. If we want to create
 * another class which can be seen by other parts of our program we must create
 * a new java file and make the class public as we did here with the Rectangle.
 */
public class Rectangle {
    
    /**
     * The following is a private data member representing the length of 
     * a rectangle. This data member can only be seen in the class. In other
     * words we cannot access it in any other parts of our program. The only 
     * way we can get or set this data member is through the getters and setters
     * after the object has been constructed. If we were to make this data member
     * public we could access it by the object reference variable but this causes
     * security ramifications. For best practice keep instance data members private.
     */
    private int length; 
    
    /**
     * The following is a private data member representing the width of 
     * a rectangle. This data member can only be seen in the class. In other
     * words we cannot access it in any other parts of our program. The only 
     * way we can get or set this data member is through the getters and setters
     * after the object has been constructed. If we were to make this data member
     * public we could access it by the object reference variable but this causes
     * security ramifications. For best practice keep instance data members private.
     */
    private int width;
    
    /**
     * The following is a private static data member representing the number of 
     * rectangle objects created. This data member can only be seen in the class. 
     * In other words we cannot access it in any other parts of our program. 
     * 
     * For this particular data member it should only be manipulated through the 
     * class itself. This is why we will only create a getter method to view the
     * number of rectangles created. Throughout the class you will notice the
     * data member is referenced using the class name. This is valid but is not 
     * required. It is to show how to access static data members as we cannot 
     * access them through instance references. 
     * 
     * The only time we would ever make a static data member public is if we 
     * include the final keyword ensuring it cannot be changed by another developer
     * or user. This avoids corruption of the object.
     */
    private static int NUM_OF_RECTANGLE;
    
    /**
     * The following is a no-arg constructor (default constructor) for the 
     * Rectangle class with two parameters allowing the data members of this 
     * class to be set when this constructor is invoked with two integer primitives.
     * 
     * As this constructor has no parameters the data members of this class
     * will retain their default values unless directly specified otherwise.
     * An example would be setting the length to 10 directly in the data member.
     * The other purpose of this constructor is to increment the number of rectangle
     * objects created by adding 1 to the NUM_OF_RECTANGLE static data member.
     */
    public Rectangle() {
        Rectangle.NUM_OF_RECTANGLE++;
    }

    /**
     * The following is a constructor for the Rectangle class with two 
     * parameters allowing the data members of this class to be set when 
     * this constructor is invoked with two integer primitives.
     * 
     * As this constructor has parameter names which match the data member 
     * names we must use the 'this' operator to allow the compiler to 
     * distinguish between the variables. The 'this' operator allows a direct 
     * reference to the data members of the class as well as it's method. The 
     * operator can only be used within a class.
     * 
     * The other purpose of this constructor is to increment the number of rectangle
     * objects created by adding 1 to the NUM_OF_RECTANGLE static data member.
     * @param length
     * @param width
     */
    public Rectangle(int length, int width) {
        this.length = length;
        this.width = width;
        Rectangle.NUM_OF_RECTANGLE++;
    }
    
    /**
     * The following is an instance method which is bound specifically to the instance 
     * of the rectangle object which created it. Instance methods cannot access the 
     * data members of other rectangle objects as they have a dedicated and separate 
     * memory location unlike static methods. Instance methods are able to access static
     * data members, instance data members, static methods, and other instance methods.
     * 
     * The purpose of this method (getter method) is to simply 'get' the value of the 
     * length data member as it's visibility is private meaning we cannot access it any 
     * other way. Any getter method must have a return type which matches the data member 
     * to be returned.
     * @return
     */
    public int getLength() {
        return length;
    }

    /**
     * The following is an instance method which is bound specifically to the instance 
     * of the rectangle object which created it. Instance methods cannot access the 
     * data members of other rectangle objects as they have a dedicated and separate 
     * memory location unlike static methods. Instance methods are able to access static
     * data members, instance data members, static methods, and other instance methods.
     * 
     * The purpose of this method (setter method) is to simply 'set' the value of the 
     * length data member as it's visibility modifier is private. Through this method
     * we can add conditions to restrict the range of possible values set for this data member.
     * @param length
     */
    public void setLength(int length) {
        
        if(length > 0) {
            this.length = length;
        }
        else {
            System.out.println("Unable to set a negative length.");
        }
    }

    /**
     * The following is an instance method which is bound specifically to the instance 
     * of the rectangle object which created it. Instance methods cannot access the 
     * data members of other rectangle objects as they have a dedicated and separate 
     * memory location unlike static methods. Instance methods are able to access static
     * data members, instance data members, static methods, and other instance methods.
     * 
     * The purpose of this method (getter method) is to simply 'get' the value of the 
     * width data member as it's visibility is private meaning we cannot access it any 
     * other way. Any getter method must have a return type which matches the data member 
     * to be returned.
     * @return
     */
    public int getWidth() {
        return width;
    }

    /**
     * The following is an instance method which is bound specifically to the instance 
     * of the rectangle object which created it. Instance methods cannot access the 
     * data members of other rectangle objects as they have a dedicated and separate 
     * memory location unlike static methods. Instance methods are able to access static
     * data members, instance data members, static methods, and other instance methods.
     * 
     * The purpose of this method (setter method) is to simply 'set' the value of the 
     * width data member as it's visibility modifier is private. Through this method
     * we can add conditions to restrict the range of possible values set for this data member.
     * @param width
     */
    public void setWidth(int width) {
        
        if(width > 0) {
            this.width = width;
        }
        else {
            System.out.println("Unable to set a negative width.");
        }
    }
    
    /**
     * The following is a static method which is shared with all rectangle objects.
     * Static methods may only access static data members and other static members.
     * Static methods cannot access instance methods or instance data properties as 
     * the purpose of using the word static is to be shared across all objects of the
     * same type.
     * 
     * The purpose of this method (getter method) is to return the number of rectangle 
     * objects created from the classes constructor where NUM_OF_RECTANGLE is incremented 
     * for every rectangle object created.
     * @return
     */
    public static int getRectangleCount() {
        return Rectangle.NUM_OF_RECTANGLE;
    }
    
    @Override
    public String toString() {
        return "Rectangle{" + "length=" + this.length + ", width=" + this.width + '}';
    }
}

/**
 * This is another class residing in the rectangle class file.
 * Only the rectangle class can create objects of this class.
 * Since we can only have one public class per file any other 
 * classes created in this file will only be seen by the classes
 * which are in it.
 */
class AnotherClass
{
    
}
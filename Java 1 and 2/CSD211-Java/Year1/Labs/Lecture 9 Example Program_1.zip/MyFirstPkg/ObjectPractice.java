package MyFirstPkg;

// In order to utulize the rectangle object we must import it from it's package. 
import Models.Rectangle;

public class ObjectPractice {
    
    public static void main(String[] args)  {
        
        /**
         * The following is the creation of two different rectangle objects.
         * The first is using the default constructor and the second is using
         * the constructor with arguments. The first rectangle will have a 
         * default value of 0 for both length and width. The second rectangle 
         * will have a set value of 12 for length, and 10 for width. 
         * These values are the initialization values as they are set during
         * object creation. 
         */
        Rectangle rect1 = new Rectangle();
        Rectangle rect2 = new Rectangle(12, 10);
        
        // Print out the initialized length and width of the two rectangles. 
        printRectangleLengthAndWidth(rect1, rect2);
        
        // Print out the number of objects created.
        printNumOfRectanglesCreated();
        
        // Change the values of both rectangles using the setter methods. 
        rect1.setLength(100);
        rect1.setLength(120);
        
        // Notice how we get a message saying we cannot set a negative value. 
        // The object retains it's previous length as it cannot be a negative. 
        rect1.setLength(-10);
        rect1.setLength(50);
        
        // Print out the initialized length and width of the two rectangles.
        printRectangleLengthAndWidth(rect1, rect2);
        
        /**
         * Note: To avoid having to code a method to print out the data members 
         * of an object we can use the toString() method in the class itself,
         * rather then having to code it as below. 
         */
        System.out.println(rect2.toString());
        System.out.println(rect1.toString());
    }
    
    /**
     * This method accepts two rectangle objects as it's parameters. 
     * Using the instance variables of the rectangles we print out
     * the length and width using their getters and setters. 
     * @param rect1
     * @param rect2
     */
    public static void printRectangleLengthAndWidth(Rectangle rect1, Rectangle rect2) {
        System.out.println("The length and width of rect1 is: " + rect1.getLength() + " and " + rect1.getWidth());
        System.out.println("The length and width of rect2 is: " + rect2.getLength() + " and " + rect2.getWidth());
        System.out.println("");
    }
    
    /**
     * This method simply prints the number of rectangles created. 
     * We do not need any parameters as the number of rectangles created
     * is accessed through a static method. 
     */
    public static void printNumOfRectanglesCreated() {
        System.out.println("The number of rectangles created is: " + Rectangle.getRectangleCount());
        System.out.println("");
    }
}
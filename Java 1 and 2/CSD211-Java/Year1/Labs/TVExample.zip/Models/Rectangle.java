package Models;

public class Rectangle 
{
    private int length;
    private int width;
    private static int count = 0;
    public static final int OPTION_3 = 2;
    
    // Default constructor.
    public Rectangle(){
        this.count++;
    }
    
    public Rectangle(int length, int width) {
        
        this.length = length;
        this.width = width;
        this.count++;
    }
    
    public void setLength(int length){
        
        if(length >= 0){
            this.length = length;    
        }
        else {
            System.out.println("This is an invalid number for length");
        }
    }
    
    public void setwidth(int width){
        this.width = width;
    }
    
    public int getLength(){
        return this.length;
    }
    
    public int getWidth(){
        return this.width;
    }
    
    public static int getNumOfObjs()
    {
        return count;
    }
    
    public int getArea()
    {
        return length * width;
    } 
}
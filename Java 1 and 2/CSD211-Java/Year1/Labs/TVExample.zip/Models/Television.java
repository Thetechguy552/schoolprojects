package Models; 

public class Television 
{
    private boolean on;
    private int channel;
    private int volume;

    public Television() {
    }
    
    public boolean isOn() {
        return on;
    }
    
    public int getCurrentChannel() {
        return channel;
    }
    
    public int getCurrentVolume() {
        return volume;
    }
    
    public void turnOn(){
        this.on = true;
    }
    
    public void turnOff(){
        this.on = false;
    }
    
    public void setVolume(int volume) {
        if(volume >= 0 && volume <= 100 && this.isOn()){
            this.volume = volume;    
        }
    }

    public void setChannel(int incChannel) {
        
        if(incChannel >= 0 && incChannel <= 100 && this.isOn()){
            this.channel = incChannel;    
        }
    }

    public void volumeUp() {
        
        if(this.getCurrentVolume() < 100 && this.isOn()){
            this.channel++;
        }
    }
    
    public void volumeDown() {
        
        if(this.getCurrentVolume() > 0 && this.isOn()){
            this.volume--;
        }
    }

    @Override
    public String toString() {
        return "Television{" + "on=" + on + ", channel=" + channel + ", volume=" + volume + '}';
    }
}
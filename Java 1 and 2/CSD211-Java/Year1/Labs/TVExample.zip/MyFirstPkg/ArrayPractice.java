package MyFirstPkg;
import Models.Television;

public class ArrayPractice {

    public static void main(String[] args) {
        
        Television tv1 = new Television();
        System.out.println(tv1.toString());
        
        tv1.setChannel(1000);
        tv1.setVolume(-1000);
        
        System.out.println(tv1.toString());
        
        tv1.setChannel(50);
        tv1.setVolume(40);
        
        System.out.println(tv1.toString());
        
        tv1.turnOn();
        tv1.setChannel(50);
        tv1.setVolume(40);
        
        System.out.println(tv1.toString());
        
        tv1.setChannel(1000);
        tv1.setVolume(-1000);
        
        System.out.println(tv1.toString());
        
        tv1.volumeUp();
        
        System.out.println(tv1.toString());
        
        tv1.volumeDown();
        
        System.out.println(tv1.toString());
        
//        Rectangle rect1 = new Rectangle(10, 10);
//        rect1.setLength(10);
//        rect1.setLength(-1);
//        System.out.println(rect1.getLength());
//        System.out.println(rect1.getWidth());
//        
//        System.out.println(rect1.getArea());
//        
//        System.out.println("------------");
//        
//        Rectangle rect2 = new Rectangle(12, 10);
//        Rectangle rect = new Rectangle(12, 10);
//        System.out.println(rect2.getArea());
//        
//        System.out.println(Rectangle.getNumOfObjs());
    }
}
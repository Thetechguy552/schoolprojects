package Models;

/**
 * Calculates a person's body mass index.
 * This class is immutable.
 */
public class BMIClass {
 
    private String name; 
    private int age;
    private double weight; 
    private double height; 
    
    // These two numbers are constants. Thus they can be public. 
    // A user may want to use these numbers in another part of the program.
    public static final double KILOGRAMS_PER_POUND = 0.45359237; 
    public static final double METERS_PER_INCH = 0.0254;
    
    // The default age is private as only the class needs to know this information.
    // A user can find out the default age by reading the java docs. 
    private static final int DEFAULT_AGE = 20;

    /**
     * Initializes all data members except age. 
     * When not specified, age will be set to it's default value of 20.
     * Notice how the this keyword invokes the constructor with more arguments.
     * @param name
     * @param weightInPounds
     * @param heightInInches
     */
    public BMIClass(String name, double weightInPounds, double heightInInches) {
        this(name, DEFAULT_AGE, weightInPounds, heightInInches);
    }
    
    /**
     * Initializes all data members of the class.
     * @param name
     * @param age
     * @param weight
     * @param height
     */
    public BMIClass(String name, int age, double weight, double height) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
    }
    
    public double getBMI(){
        double bmi = this.weight * KILOGRAMS_PER_POUND / ((this.height * METERS_PER_INCH) * (this.height * METERS_PER_INCH));
        return Math.round(bmi);
    }
    
    public String getStatus(){
        double bmi = getBMI();
        
        if(bmi < 18.5) 
            return "Underweight";
        else if(bmi < 25) 
            return "Normal";
        else if(bmi < 30) 
            return "Overweight";
        else 
            return "Obese";
    }
            
    public String getName() {
        return name;
    }

    public double getWeight() {
        return weight;
    }

    public double getHeight() {
        return height;
    }
    
    public String printBMI() {
        return "The BMI for: " + this.getName() + " is " + this.getBMI() + " " + this.getStatus();
    }
}
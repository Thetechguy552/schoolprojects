package Models;

/**
 * The following class is an example of an immutable class which can be used
 * to create an immutable object like the string class.
 * Notice in this class it only consists of getter methods and all the data
 * fields are private. This denotes the object cannot be changed thus making
 * it immutable. 
 * 
 * For a class to be immutable the following must be met:
 * 1) All data fields must be private.
 * 2) There can't be any mutator methods for data fields (setters).
 * 3) No accessor methods can return a reference to a data field that is mutable.
 * Note: An example of point 3 would be returning a date object where that 
 * object can be changed through it's setter somewhere else in the program.
 */
public class ImmutableClassExample {
    
    private int Id;
    private String name;
    
    public ImmutableClassExample(int ssn, String newName) {
        this.Id = ssn;
        this.name = newName;
    }

    public int getId() {
        return Id;
    }

    public String getName() {
        return name;
    }
}
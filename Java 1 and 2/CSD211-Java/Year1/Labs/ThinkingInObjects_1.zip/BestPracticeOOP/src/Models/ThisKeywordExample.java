package Models;

/**
 * This class demonstrates the use of the this keyword in regards
 * to the class's data members, constructors, and methods. 
 * 
 * It is best practice that a constructor with fewer or no parameters invokes 
 * a constructor with more parameters. 
 */
public class ThisKeywordExample {
    
    private int temp;
    
    /**
     * Default constructor. 
     * The purpose of this constructor is to initialize the default values
     * for the class. According to best practice we should call the constructor
     * with arguments to initialize them using the this keyword to invoke a constructor. 
     * This allows us to prevent duplicate code when initialing constructors. 
     * 
     * When we invoke a constructor using this it MUST be the first line in the constructor. 
     * All proceeding lines of code must be after.
     */
    public ThisKeywordExample() {
        this(1);
        // Additional lines of codes if required.
    }
    
    /**
     * Constructor with parameters.
     * Invoked by the default constructor. 
     * @param temp
     */
    public ThisKeywordExample(int temp) {
        this.temp = temp;
    }
    
    /**
     * Invoking a class's method using the this keyword.
     */
    public void invokeClassMethod(){
        String classDef = this.toString();
    }

    @Override
    public String toString() {
        return "ThisKeywordExample{" + "temp=" + temp + '}';
    }
}
package Models;

/**
 * The scope of instance and static variables is the entire class, regardless
 * of where the variables are declared. Instance and static variables are 
 * referred to as class variables. For example in the following class
 * it does not matter where the data members are declared. They will 
 * be treated the same regardless of placement. This also includes the 
 * class's methods and constructors. 
 * 
 * The only exception to this rule is when a data field is initialized 
 * based on a reference to another data field. 
 * 
 * Although with this said it is best practice to keep data members
 * at the top of the class, followed by the constructors, then followed
 * by the behavioral methods. 
 * 
 */
public class VariableClassScopeExample {
    
    // In this scenario i must be declared before j in order for this class to compile.
    private int i = 10; 
    private int j = i + 15; 
    
    public double getArea(){
        return this.radius * this.radius * Math.PI;
    }
    
    private double radius = 1;
    
    public VariableClassScopeExample(double radius){
        this.radius = radius;
    }
    
    public void printDifferentRadius(){
        
        // With this method the local variable radius will take precedence 
        // over the class data member. We use the this keyword to distinguish them.
        int radius = 10; 
        System.out.println(radius);
    }
    
    private final static String CIRCLE_NAME = "My Circle";

    @Override
    public String toString() {
        return "VariableClassScopeExample{" + "radius=" + radius + '}';
    }
}
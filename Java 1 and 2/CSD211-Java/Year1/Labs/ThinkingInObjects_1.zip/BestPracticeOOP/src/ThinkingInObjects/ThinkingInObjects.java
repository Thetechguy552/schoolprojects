package ThinkingInObjects;

import Models.BMIClass;

public class ThinkingInObjects {
    
    public static void main(String[] args) {
       
        BMIClass bmi1 = new BMIClass("RandomGuy", 18, 145, 70);
        System.out.println(bmi1.printBMI());
        
        BMIClass bmi2 = new BMIClass("AnotherRandomGuy", 215, 70);
        System.out.println(bmi2.printBMI());
    }   
}
package ca.saultcollege.csd221_w18_jonathankelly;


/**
 * Jonathan Kelly
 * @author 15015608
 */
public class Greeter 
    {
        public static void greet() {
        System.out.println("Hello world!!");
        }
        public static void emotion() {
        System.out.println("Hey");
        }
    
}

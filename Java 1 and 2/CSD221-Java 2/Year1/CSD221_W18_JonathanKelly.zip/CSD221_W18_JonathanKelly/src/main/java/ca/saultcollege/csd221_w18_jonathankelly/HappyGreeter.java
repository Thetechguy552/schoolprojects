package ca.saultcollege.csd221_w18_jonathankelly;


/**
 * Jonathan Kelly
 * @author 15015608
 */
public class HappyGreeter 
{
        public static void happygreet() {
        System.out.println("Hello, wonderful world!!");
        }
        public static void happyemotion() {
        System.out.println("cheers");
        }
}

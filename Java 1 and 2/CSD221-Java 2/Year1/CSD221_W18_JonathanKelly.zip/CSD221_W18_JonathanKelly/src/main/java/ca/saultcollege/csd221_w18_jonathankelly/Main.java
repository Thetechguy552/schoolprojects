package ca.saultcollege.csd221_w18_jonathankelly;


/**
 * Jonathan Kelly
 * @author 15015608
 */
public class Main {
    public static void main(String[] args) {
        Greeter greet = new Greeter();
        HappyGreeter happygreet = new HappyGreeter();
        SadGreeter sadgreet = new SadGreeter();
        
        greet.greet();
        greet.emotion();
        happygreet.happygreet();
        happygreet.happyemotion();
        sadgreet.sadgreet();
        sadgreet.sademotion();
    }    
}

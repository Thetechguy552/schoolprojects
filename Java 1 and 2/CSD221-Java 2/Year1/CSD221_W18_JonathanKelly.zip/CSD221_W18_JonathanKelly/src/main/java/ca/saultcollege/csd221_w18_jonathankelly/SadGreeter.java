package ca.saultcollege.csd221_w18_jonathankelly;


/**
 * Jonathan Kelly
 * @author 15015608
 */
public class SadGreeter 
{
        public static void sadgreet() {
        System.out.println("Hello, cruel world!!");
        }
        public static void sademotion() {
        System.out.println("Crys");
        }
}

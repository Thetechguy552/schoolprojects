/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.saultcollege.csd221.w18.Quizzard;

import java.util.Scanner;

/**
 * This class manages all the command line input for the app.
 * 
 * @author rod
 */
public class InputController {
    
    private final Scanner scanner;
    
    public InputController(Scanner scanner) {
        this.scanner = scanner;
    }
    
    /**
     * Prompts the user for their name and returns their response.
     * 
     * @return The response given by the user at the command line
     */
    public String askForUserInfo() {
        
        return promptForString("Enter your name");
        
    }
        
    /**
     * Asks the user if they want another round and returns their response
     * 
     * @param name The user's name
     * @return Returns true if the user responded 'y' to the prompt; 
     * false otherwise
     * 
     */
    public boolean userWantsAnotherRound(String name) {
        
        return promptForBooleanInput("Would you like to play again, " + name + "?");
        
    }
    
    /**
     * Asks the user if they want to use the same preferences for the next
     * round of quiz questions and returns their response
     * 
     * @return Returns true if the user responded 'y'; false otherwise
     */
    public boolean userWantsSamePreferencesAgain() {
        return promptForBooleanInput("Would you like to use the same number and type of questions as last time?");
    }
    
    /**
     * Asks the user for the number of questions they'd like and returns their
     * response
     * 
     * @return The Integer value for the number of questions the user would like
     */
    public Integer askForNumberOfQuestions() {
        return promptForIntegerInput("How many questions would you like?", 1, 20);
    }
    
    /**
     * Asks the user which type of question they would like and returns their
     * response.
     * 
     * @return One of 'addition' 'subtraction' 'multiplication' or 'any'
     * 
     */
    public String askForQuestionType() {
        String[] options = new String[]{ "addition", "subtraction", "multiplication", "any" };
        int response = promptForSpecificOption("What would you like to practice?", options);
        return options[response];
    }
    
    /**
     * Prompts the user with a message and returns their response
     * 
     * @param message The message to prompt the user with
     * @return Returns the String input the user responded with
     */
    private String promptForString(String message) {
        System.out.println(message + ": ");
        
        return scanner.next(); 
    }
    
    /**
     * Prompts the user with a y/n questions and returns their response
     * 
     * @param message The message to prompt the user with
     * @return Returns true if the user responded 'y'; false otherwise
     */
    private boolean promptForBooleanInput(String message) {
        int response = promptForSpecificOption(message, new String[]{ "y", "n" });
        
        if ( response == 0 ) { // index 0 means the user selected option 'y'
            return true; 
        }
        
        return false;
    }
    
    /**
     * Prompts the user for an integer and returns their response
     * 
     * @param message The message to prompt the user with
     * @return Returns the Integer the user responded with
     */
    private Integer promptForIntegerInput(String message) {

        System.out.println(message);

        while ( true ) {
            
            String response = scanner.next();
            
            // check if the response is an integer
            if ( response.trim().matches("^[-+]?\\d+$") ) {
                return Integer.parseInt(response);
            } else {
                System.out.println("Please enter a number");
            }
            
        }
        
    }
    
    /**
     * Prompts the user for an integer with in a specified range and returns
     * their response
     * @param message The message to prompt the user with
     * @param min The minimum integer that will be accepted from the user
     * @param max The maximum integer that will be accepted from the user
     * @return Returns the Integer the user responded with
     */
    private Integer promptForIntegerInput(String message, Integer min, Integer max) {            

        System.out.println(message);

        while ( true ) {

            System.out.println("Please enter a number from " + min.toString() + " to " + max.toString() + ":");

            
            String response = scanner.next();
            
            // check if the response is an integer
            if ( response.trim().matches("^[-+]?\\d+$") ) {
                
                Integer i = Integer.parseInt(response);
                
                if ( min <= i && i <= max ) {
                    return i;
                }
            }
            
        }

        
    }
    
    /**
     * Prompts the user for one of an array of options, and returns the index
     * of the option that the user selected.  The user may enter either the full
     * text of the option, or the numbers 1 to options.length to select the
     * corresponding option.
     * 
     * @param message The message to prompt the user with
     * @param options An array of Strings that are the valid options
     * @return Returns index of the option that the user selected
     * 
     */
    private int promptForSpecificOption(String message, String[] options) {
        
        char[] optionShortcuts = new char[options.length];
        for ( int i = 0 ; i < options.length ; ++i ) {
            optionShortcuts[i] = Character.forDigit(i + 1, 10);
        }
        
        return promptForSpecificOption(message, options, optionShortcuts);
    }
    
    /**
     * Prompts the user for one of an array of options, and returns the index
     * of the option that the user selected.  The user may enter either the full
     * text of the option, or the corresponding optionShortcuts char.
     * 
     * @param message The message to prompt the user with
     * @param options An array of Strings that are valid responses from the user
     * @param optionShortcuts  An array of Characters that can be used as
     * shortcuts instead of the full option in the options array.
     * optionShortcut[i] must correspond to options[i] and must have the same
     * length as options.  If optionShortcuts is null no shortcuts will be made
     * available to the user.
     * @return Returns the index of the option that the user selected
     */
    private int promptForSpecificOption(String message, String[] options, char[] optionShortcuts) {
                    
        String response;
        // Loop until the user gives a valid response
        while ( true ) {

            System.out.println(message);
            System.out.println(getValidOptionsString(options, optionShortcuts));
            response = scanner.next();

            // Search through the list of valid responses to see if the
            // user's response matches any of them
            for ( int i = 0 ; i < options.length ; ++i ) {

                // Test for both the full option string or the shortcut
                if ( response.equals(options[i]) || ( response.length() == 1 && response.charAt(0) == optionShortcuts[i]) ) {
                    // if we find a match, return the current index
                    return i;
                }
            }

            // if we get here, the user must not have given use a valid
            // response, so we'll need to prompt them again
            System.out.println("I'm sorry, I didn't understand.");

        }
            
        
    }
    
    /**
     * This method generates a message string to inform the user which
     * inputs are valid for a prompt.  
     * 
     * Example: if validResponses = new String[]{ "y", "n" } the return
     * string will be:
     *     Valid responses: y, n
     * @param options An array of valid option Strings
     * @param optionShortcuts An array of shortcuts corresponding to the options
     * array.  Must be the same length as the options array.
     * @return A message to tell the user which inputs are valid.
     * 
     */
    private String getValidOptionsString(String[] options, char[] optionShortcuts) {
        
        String optionsString = "";
        
        for ( int i = 0 ; i < options.length ; ++i ) {
            if ( optionShortcuts == null ) {
                optionsString += options[i] + System.getProperty("line.separator");
            } else {
                optionsString += "(" + optionShortcuts[i] + ") " + options[i] + System.getProperty("line.separator");
            }
            
        }
        
        return optionsString;
    }
}

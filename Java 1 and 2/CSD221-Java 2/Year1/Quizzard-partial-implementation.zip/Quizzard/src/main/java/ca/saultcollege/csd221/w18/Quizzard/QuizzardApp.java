/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.saultcollege.csd221.w18.Quizzard;

/**
 * 
 * @author rod
 */
public class QuizzardApp {
    
    String userName;
    InputController input;
    
    public QuizzardApp(InputController input) {
        this.input = input;
    }
 
    /**
     * This is the main loop of the app.  The basic flow is to prompt the user
     * for their name and then loop through any number of rounds of quizzes that
     * the user chooses.  For each round, the user will be prompted for the
     * number of questions they want to do and the type of question.  The app
     * will then display a set of questions for the user to answer based on the
     * preferences they set.
     */
    public void play() {
        
        userName = input.askForUserInfo();
        
        RoundPreferences currentPrefs = null;
        
        do {
        
            // See docs for the getRoundPreferences method
            currentPrefs = getRoundPreferences(currentPrefs);
            
            // TODO: REPLACE THE FOR LOOP BELOW WITH YOUR OWN CODE
            // See Lab 2 question 3.4
            
            for ( int i = 0 ; i < currentPrefs.numberOfQuestions ; ++i ) {
                System.out.println("TODO: finish your lab");
            }
            
            
        } while ( input.userWantsAnotherRound(userName) );

    }
    
    /**
     * The Quizzard app allows the user to play multiple rounds of quizzes, and
     * each time it asks the user whether it wants to use the same preferencse
     * as the previous round or not.  The first round it simply asks the user
     * for their preferences.
     * 
     * @param currentRoundPreferences The current preferences set by the user.
     * This should be null the first time through because the user has not set
     * any preferences yet.
     * @return Returns the user's preference of number of questions and question
     * type encapsulated in a RoundPreferences instance.
     * 
     */
    private RoundPreferences getRoundPreferences(RoundPreferences currentRoundPreferences) {
        
        RoundPreferences preferences;
        
        // When currentRoundPreferences is not null, it means that this isn't
        // the user's first round, so we should ask if they want to use the
        // same settings for the next round or not
        if ( currentRoundPreferences != null && input.userWantsSamePreferencesAgain() ) {
            // If they want the same prefs just use the current ones
            preferences = currentRoundPreferences;
            
        } else {
            
            // If they want different prefs, or this is the first round
            // ask the user for their preferences.
            
            preferences = new RoundPreferences();
            
            preferences.numberOfQuestions = input.askForNumberOfQuestions();
            preferences.questionType = input.askForQuestionType();
            
        }
        
        return preferences;
    }
    
    /**
     * Shows a report of the number of tries the user made for each question
     * that was asked.
     * 
     * @param questions The array of questions that was asked
     * @param tries The number of tries the user had to take for each question
     * 
     */
    public void showReport(Object[] questions, int[] tries) {
        System.out.println();
        System.out.println("Report:");
        for ( int i = 0 ; i < questions.length ; ++i ) {
            
//            String report = (i+1) + ") " + questions[i].toString() + " = " + questions[i].answer();
//            if ( tries[i] == 1 ) {
//                report += " ✓";
//            } else {
//                report += " (" + tries[i] + " tries)";
//            }
//            
//            System.out.println(report);
       }
        System.out.println();
    } 
    
 
}

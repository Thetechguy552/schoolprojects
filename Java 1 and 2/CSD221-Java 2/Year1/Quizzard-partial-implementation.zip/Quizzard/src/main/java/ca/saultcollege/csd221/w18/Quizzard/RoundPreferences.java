/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.saultcollege.csd221.w18.Quizzard;

/**
 * This class is simply meant to store a set of fields in one place,
 * so I feel OK about just making the fields public and not having
 * setter / getter methods
 * 
 * @author rod
 */
public class RoundPreferences {
      
    public Integer numberOfQuestions;
    public String questionType;
    
}
